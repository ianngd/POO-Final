def menu_principal ():
    print ('\nEscolha um Menu:')
    print('0 - Sair')
    print('1 - Humanos')
    print('2 - Cachorros')    
    print('Digite a opção desejada: ')

### MENUS CACHORRO
def menu_dog_principal():
    print('0 - Sair')
    print('1 - Criar cachorro')
    print('2 - Visualizar Cachorros')
    print('3 - Brincar com cachorros')
    print('Digite a opção desejada: ')

def menu_sexo_dog():
   print ('Qual o sexo do cachorro: ') 
   print('\n1 - Femea\n2 - Macho: ')

def menu_porte_dog():
    print('Informe o porte do cachorro:')
    print('\n1 - Grande\n2 - Médio\n3 - Pequeno: ')

def menu_brincar_dog ():
    print ('')

###MENUS HUMANO ###
def menu_humano_principal():
    print('0 - Sair')
    print('1 - Criar humano')
    print('2 - Visualiar Humanos')

def menu_cor ():
    print ('Defina a cor:')
    print('\n1 - Branca\n2 - Parda\n3 - Preta\n4 - Amarela: ')

def menu_sexo_humano():
    print('Sexo:')
    print('\n1 - Masculino\n2 - Feminino\n3 - Prefiro não responder: ')
   
def menu_instrucao():
    print ('Qual o grau de instrução:\n')
    print('1 - Ensino fundamental')
    print('2 - Ensino Médio')
    print('3 - Ensino Técnico')
    print('4 - Ensino Superior ou Mais')
